Sprite Shaders URP:
- Contains shadergraphs for the universal render pipeline.
- This was an older version of this asset before I remade everything from scratch.
- Just included for people who want to use the old shadergraphs.

Removed Shaders:
- Shaders I decided to not include in my main asset anymore.
- Mostly because other better shaders replaced them.